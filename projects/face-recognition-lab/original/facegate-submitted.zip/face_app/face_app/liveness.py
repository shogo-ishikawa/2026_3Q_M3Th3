"""【独自機能】チャレンジ認証(写真・画面によるなりすまし対策)。

顔認証は「本人の写真」をカメラに見せるだけで突破されるおそれがある。
そこでランダムな指示(画面の右を向く/左を向く/笑顔)を出し、制限時間内に
その通り動けた場合だけ「本人確認済み」とする。指示はその都度ランダムなので、
動画を前もって用意しておくことも難しい。
"""
from __future__ import annotations

import random
import time

from . import config

STEPS = {
    "right": "画面の右を向いてください",
    "left": "画面の左を向いてください",
    "smile": "笑顔を見せてください",
    "front": "正面を向いてください",
}
HOLD_FRAMES = 4


class Challenge:
    def __init__(self, track_id: int, start_name: str, rng=None, clock=time.monotonic):
        self.rng = rng or random.Random()
        self.clock = clock
        self.track_id = track_id
        self.start_name = start_name
        pool = ["right", "left", "smile"]
        steps = []
        while len(steps) < config.CHALLENGE_STEPS:
            s = self.rng.choice(pool)
            if not steps or steps[-1] != s:
                steps.append(s)
        # 向きの指示のあとは正面に戻してから次へ(同じ姿勢のまま通過するのを防ぐ)
        self.steps = []
        for s in steps:
            self.steps.append(s)
            if s in ("left", "right"):
                self.steps.append("front")
        if self.steps[-1] == "front":
            self.steps.pop()
        self.index = 0
        self.hold = 0
        self.step_started = self.clock()
        self.state = "running"     # running / passed / failed
        self.message = ""

    @property
    def instruction(self) -> str:
        if self.state != "running":
            return self.message
        return f"[{self.index + 1}/{len(self.steps)}] {STEPS[self.steps[self.index]]}"

    @property
    def remaining(self) -> float:
        return max(0.0, config.CHALLENGE_STEP_SEC - (self.clock() - self.step_started))

    def _ok(self, step, yaw, probs) -> bool:
        if step == "right":
            return yaw > config.YAW_TURN
        if step == "left":
            return yaw < -config.YAW_TURN
        if step == "front":
            return abs(yaw) < config.YAW_TURN * 0.5
        if step == "smile":
            return probs is not None and probs[1] > config.SMILE_PROB
        return False

    def update(self, track) -> str:
        """毎フレーム呼ぶ。track は対象の顔の追跡(見失ったら None)。"""
        if self.state != "running":
            return self.state
        if track is None or track.id != self.track_id:
            return self._fail("顔を見失いました。もう一度 C キーで開始してください")
        if self.remaining <= 0:
            return self._fail("時間切れです。もう一度 C キーで開始してください")
        # 途中で別人に入れ替わったら失敗(多数決で確定した名前で判断)
        if track.name not in ("判定中", self.start_name):
            return self._fail("途中で人物が変わりました")
        yaw = track.quality.yaw if track.quality else 0.0
        if self._ok(self.steps[self.index], yaw, track.raw_emotion):
            self.hold += 1
        else:
            self.hold = 0
        if self.hold >= HOLD_FRAMES:
            self.index += 1
            self.hold = 0
            self.step_started = self.clock()
            if self.index >= len(self.steps):
                self.state = "passed"
                if self.start_name in ("未登録", "判定中"):
                    self.message = "生身の人です(ただし未登録の人物)"
                else:
                    self.message = f"本人確認OK: {self.start_name}(写真ではなく生身と判定)"
        return self.state

    def _fail(self, msg):
        self.state = "failed"
        self.message = msg
        return self.state
