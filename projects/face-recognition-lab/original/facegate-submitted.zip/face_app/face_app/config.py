"""共通設定。数値はここを変えれば全体に反映されます。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MODEL_DIR = ROOT / "models"
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "face_db.npz"
DB_META_PATH = DATA_DIR / "face_db.json"
LOG_DIR = ROOT / "logs"
REPORT_DIR = ROOT / "reports"
SHOT_DIR = ROOT / "screenshots"

# --- モデル(初回に python main.py download で取得) ---
MODELS = {
    "detector": {
        "file": "face_detection_yunet_2023mar.onnx",
        "url": "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx",
    },
    "recognizer": {
        "file": "face_recognition_sface_2021dec.onnx",
        "url": "https://github.com/opencv/opencv_zoo/raw/main/models/face_recognition_sface/face_recognition_sface_2021dec.onnx",
    },
    "emotion": {
        "file": "emotion-ferplus-8.onnx",
        "url": "https://github.com/onnx/models/raw/main/validated/vision/body_analysis/emotion_ferplus/model/emotion-ferplus-8.onnx",
    },
}

# --- 照合 ---
# SFace のコサイン類似度の推奨しきい値は 0.363。evaluate コマンドで自分たちのデータに合わせて調整する。
DEFAULT_THRESHOLD = 0.363
DETECT_SCORE = 0.8          # 顔検出の信頼度しきい値

# --- 感情ラベル(FER+ の出力順) ---
EMOTIONS_EN = ["neutral", "happiness", "surprise", "sadness",
               "anger", "disgust", "fear", "contempt"]
EMOTIONS_JA = ["中立", "喜び", "驚き", "悲しみ", "怒り", "嫌悪", "恐れ", "軽蔑"]
# 表示色 (BGR)
EMOTION_COLORS = [
    (180, 180, 180), (60, 200, 255), (255, 200, 60), (220, 120, 40),
    (40, 40, 230), (60, 160, 60), (160, 60, 160), (120, 120, 60),
]
# 「場の空気メーター」用の重み(ポジティブ +, ネガティブ -)
MOOD_WEIGHTS = [0.0, 1.0, 0.3, -1.0, -1.0, -0.8, -0.7, -0.5]

# --- 平滑化(多数決) ---
VOTE_WINDOW = 15            # 直近何フレームで多数決するか
VOTE_MIN_RATIO = 0.6        # 何割以上一致したら確定表示するか
EMOTION_EMA = 0.3           # 感情確率の指数移動平均の係数

# --- 撮影条件(品質)の基準 ---
QUALITY = {
    "min_face": 80,          # 顔の短辺(px)
    "bright_low": 70, "bright_high": 190,
    "min_contrast": 30,
    "min_sharpness": 40,     # ラプラシアン分散
    "max_yaw": 0.30,         # 正面からのずれ(目の間隔に対する鼻のずれ)
    "max_roll": 15.0,        # 顔の傾き(度)
}
REGISTER_MIN_QUALITY = 70    # この点数未満の画像は登録しない

# --- チャレンジ認証(なりすまし防止) ---
CHALLENGE_STEPS = 3
CHALLENGE_STEP_SEC = 6.0
YAW_TURN = 0.25
SMILE_PROB = 0.55
